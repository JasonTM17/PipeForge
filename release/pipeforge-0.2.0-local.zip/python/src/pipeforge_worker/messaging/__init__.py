"""RabbitMQ transport abstractions."""
